package com.hibernate.one2one.primary;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.jdbc.Work;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;




public class HibernateTest {
	
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	@Before
	public void init(){
		System.out.println("init....");
		Configuration configuration = new Configuration().configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).buildServiceRegistry();
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
	}
	
	@After
	public void destroy(){
		System.out.println("destroy....");
		transaction.commit();
		session.close();
		sessionFactory.close();
	}
	
	
	@Test
	public  void testSave(){
		
		Department dept = new Department();
		dept.setDeptName("dept-CC");
		
		Manager mgr = new Manager();
		mgr.setMgrName("mgr-CC");
		
		//设定关系
		dept.setMgr(mgr);
		mgr.setDept(dept);
		
		session.save(dept);
		session.save(mgr);
		
//		session.save(mgr);
//		session.save(dept);
		
		//无论先插入哪个对象，都不会有多余的update
		//sql执行语句：2个insert，先插入manager 再插入department
	}
	@Test
	public void testGet(){
		Department dept = (Department)session.get(Department.class, 1);
		System.out.println(dept.getDeptName());
		
		Manager mgr = dept.getMgr();
		System.out.println(mgr.getMgrName());
	}
	@Test
	public void testGet2(){
		Manager mgr = (Manager)session.get(Manager.class, 1);
		System.out.println(mgr.getMgrName());
		//如果只查询mgr相关属性，也会关联dept表进行检索
//		Department dept = mgr.getDept();
//		System.out.println(dept.getDeptName());
	}

	
}
