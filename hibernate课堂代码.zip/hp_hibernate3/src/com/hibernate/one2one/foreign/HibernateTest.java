package com.hibernate.one2one.foreign;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.jdbc.Work;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class HibernateTest {
	
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	@Before
	public void init(){
		System.out.println("init....");
		Configuration configuration = new Configuration().configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).buildServiceRegistry();
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
	}
	
	@After
	public void destroy(){
		System.out.println("destroy....");
		transaction.commit();
		session.close();
		sessionFactory.close();
	}
	
	@Test
	public  void testSave(){
		
		Department dept = new Department();
		dept.setDeptName("dept-CC");
		
		Manager mgr = new Manager();
		mgr.setMgrName("mgr-CC");
		
		//设定关系
		dept.setMgr(mgr);
		mgr.setDept(dept);
		
//		session.save(dept);
//		session.save(mgr);
		//执行sql语句：2个insert 1个update
		
		session.save(mgr);
		session.save(dept);
		//执行sql语句：2个insert
		//建议先保存没有外键列的那个对象，这样会减少update语句
	}
	@Test
	public void testGet(){
		//1.默认情况下对关联属性使用懒加载
		Department dept = (Department)session.get(Department.class, 1);
		System.out.println(dept.getDeptName());
		
		//2.session关闭时会出现懒加载异常
//		session.close();
		
		//3.查询Manager对象的连接条件应该是dept.manager_id=mgr.manager_id
		//而不应该是dept.dept_id=mgr.manager_id
		Manager mgr = dept.getMgr();
		System.out.println(mgr.getClass().getName());
		System.out.println(mgr.getMgrName());
	}
	@Test
	public void testGet2(){
		//在查询没有外键的实体对象时，使用的左外连接查询，一并查询出其关联的对象，并已经进行初始化
		Manager mgr = (Manager)session.get(Manager.class, 1);
		System.out.println(mgr.getMgrName());
		System.out.println(mgr.getDept().getDeptName());
	}
	
}
