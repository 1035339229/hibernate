package com.hibernate.helloworld;

import static org.junit.Assert.*;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.Test;

public class HibernateTest {

	@Test
	public void test() {
		System.out.println("test...");
		//1、创建一个 SessionFactory对象
		SessionFactory sessionFactory = null;
		//1).创建一个Configuration对象，对应hibernate的基本配置信息和对象关系映射信息
		Configuration configuration = new Configuration().configure();
		//4.0之前创建方式
//		sessionFactory = configuration.buildSessionFactory();
		//2).创建一个ServiceRegistry对象：hibernate4.x新添加的对象
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).buildServiceRegistry();
		//分步写法
//		ServiceRegistryBuilder builder = new ServiceRegistryBuilder().applySettings(configuration.getProperties());
//		ServiceRegistry registry = builder.buildServiceRegistry();
		
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		
		//2、创建一个Session对象
		Session session = sessionFactory.openSession();
		//3、开启事务
		Transaction transaction = session.beginTransaction();
		//4、执行保存的操作
		News news = new News("java5","test5",new Date());
		session.save(news);
		//5、事务提交
		transaction.commit();  
		//6、关闭Session
		session.close();
		//7、关闭SessionFactory对象
		sessionFactory.close();
	}

}
