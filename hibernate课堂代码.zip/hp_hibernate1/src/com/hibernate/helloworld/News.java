package com.hibernate.helloworld;

import java.util.Date;

/**
 * 类名：首字母大写，后面的每一个单词的首字母都要大写，Student，StudentInfo,StudentScore
 * 属性名、变量名、方法名：首字母小写，后面的每个单词首字母大写，驼峰命名法。studentName getStudentName()
 * 常量： 每个单词的字母都要大写，如果有多个单词则用下划线拼接 public static final int MAX_SIZE;  DB_URL ,DB_DRIVER,
 * 包名：所有字母都小写，每个单词用点号分割，通常是域名的反向表达  com.cju.studentmgr.model
 * 
 * */
public class News {
	
	private Integer id;
	private String title;
	private String  author;
	private Date	date;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public News(String title, String author, Date date) {
		super();
		this.title = title;
		this.author = author;
		this.date = date;
	}
	//如果自己定义了带参数的构造方法，则必须要有一个无参的构造方法
	public News() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "News [id=" + id + ", title=" + title + ", author=" + author + ", date=" + date + "]";
	}
	
	

}
