package com.hibernate.helloworld;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.jdbc.Work;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
	
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	@Before
	public void init(){
		System.out.println("init....");
		Configuration configuration = new Configuration().configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).buildServiceRegistry();
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
	}
	
	@After
	public void destroy(){
		System.out.println("destroy....");
		transaction.commit();
		session.close();
		sessionFactory.close();
	}
	

	@Test
	public void test() {
		System.out.println("test...");

		News news = new News("java6","test6",new Date());
		session.save(news);
		
		System.out.println(news);

	}
	@Test
	public void testSessionCache(){
		News news = (News)session.get(News.class, 1);
		System.out.println(news);
		
		News news2 = (News)session.get(News.class, 1);
		System.out.println(news2);
		
		System.out.println(news==news2);
	}
	//flush:使数据表中的记录和Session缓存中的对象的状态保持一致，为了保持一致，则可能会发送对应的SQL语句
	@Test
	public void testSessionFlush(){
		//1.在transaction的commit方法中，先调用了session的flush方法，再提交的事务
		News news = (News) session.get(News.class, 1);
		news.setAuthor("mysql123");
		//2、flush方法可能会发送SQL语句，但是不会提交事务
		session.flush();
		System.out.println("...flush");
	}
	@Test
	public void testSessionFlush1(){
		//3 在未提交事务或显式的调用session.flush方法之前，也有可能进行flush操作
		News news = (News)session.get(News.class, 1);
		news.setAuthor("oracle456");
		//执行HQL或QBC查询，会先进行flush操作，以得到数据表中最新的记录
		News news2 = (News)session.createCriteria(News.class).uniqueResult();
		System.out.println(news2);
		System.out.println("....end ");
	}
	@Test
	public void testSessionFlush2(){
		//若记录的ID是由底层数据库使用自增的方式生成的，则在调用save方法时，会立即发送insert语句
		//因为save方法后，必须保证对象的id是存在的
		News news = new News("Java","Sun",new Date());
		
		session.save(news);
		System.out.println("...end");
		//如果变为hilo的主键方式，则不立即发送insert语句
	}
	@Test
	public void testRefresh(){
		News news = (News)session.get(News.class, 1);
		System.out.println(news);
		System.out.println("=======手动修改下DB中的数据");
		//在下面语句执行前，修改了数据库记录，发现news对象的属性值没有变化
		System.out.println(news);
	}
	@Test
	/**
	 * refresh:会强制发送select语句，以使Session缓存中对象的状态和数据表中对应的记录保持一致
	 * */
	public void testRefresh2(){
		News news = (News)session.get(News.class, 1);
		System.out.println(news);
		
		session.refresh(news);
		System.out.println(news);
		//发现refresh发送了SQL查询语句，但是news结果没变化，原因是事务的隔离级别
	}
	@Test
	public void testClear(){
		News new1 = (News) session.get(News.class, 1);
		session.clear();
		//调用clear方法后，new2又会发出一条select 语句
		News new2 = (News) session.get(News.class, 1);
	}
	
	@Test
	public void testSave(){
		//1)使一个临时对象变为持久化对象
		//2)为对象分配ID
		//3)在flush缓存时会发送一条insert 语句
		News news = new News("aa","bb",new Date());
		session.save(news);
		
		System.out.println(news);
	}
	@Test
	public void testSave1(){
		News news = new News();
		news.setAuthor("cc");
		news.setDate(new Date());
		news.setTitle("CC");
		news.setId(99);
		System.out.println("执行save前："+news);
		//4)在save方法之前的id是无效的
		session.save(news);
		System.out.println("执行save后："+news);
		
	}
	@Test
	public void testSave2(){
		News news = new News();
		news.setAuthor("dd");
		news.setDate(new Date());
		news.setTitle("DD");
		System.out.println("执行save前："+news);
		session.save(news);
		System.out.println("执行save后："+news);
		news.setId(99);
		//5) 持久化对象的ID是不能修改的
		//org.hibernate.HibernateException: 
		//identifier of an instance of com.hibernate.helloworld.News was altered from 4 to 99
	}
	/**
	 * persist():也会执行insert操作
	 * 和save的区别：
	 * 在调用persist方法之前，如果对象已经有了id，则不会执行insert，而是抛出异常
	 * */
	@Test
	public void testPersist(){
		News news = new News("a1","A1",new Date());
		session.persist(news);
		
	}
	@Test
	public void testPersist1(){
		News news = new News();
		news.setAuthor("b1");
		news.setDate(new Date());
		news.setTitle("B1");
		news.setId(99);
		session.persist(news);
		//在调用persist方法之前，如果对象已经有了id，则不会执行insert，而是抛出异常
	}
	/**
	 * 1、执行get方法：会立即加载对象
	 * 执行load方法：若不适用该对象，不会立即执行查询操作，而返回一个代理对象
	 * get是立即检索，load是延迟检索
	 * */
	@Test
    public void testLoad(){
    	News news = (News) session.load(News.class,1);
//    	System.out.println(news.getClass().getName());
    	//输出结果：com.hibernate.helloworld.News_$$_jvst2ac_0 
    	//news是一个代理对象
    	System.out.println(news.getId());
    	System.out.println("=======");
    	System.out.println(news);
    }
	@Test
	public void testGet(){
		News news = (News)session.get(News.class, 1);
//		System.out.println(news.getClass().getName());
		//输出结果：com.hibernate.helloworld.News
//		System.out.println(news);
	}
	/**
	 * load方法可能会抛出LazyInitializationException异常：在需要初始化代理对象之前已经关闭了session
	 * */
	@Test
    public void testLoad1(){
		//测试时把destroy方法中的session.close注释掉
    	News news = (News) session.load(News.class,1);
    	session.close();
    	System.out.println(news);
    }
	
	@Test
	public void testGet1(){
		News news = (News)session.get(News.class, 1);
		session.close();
		System.out.println(news);
	}
	
	/**
	 * 若数据表中没有对应的记录，session也没有被关闭
	 * get 返回null
	 * load 若不使用该对象的任何属性，没有问题。若需要初始化了，抛出异常
	 * 
	 * */
	@Test
    public void testLoad2(){
    	News news = (News) session.load(News.class,10);
    	System.out.println(news);
    	//没有id为10的记录，抛出异常：ObjectNotFoundException
    }
	@Test
	public void testGet2(){
		News news = (News)session.get(News.class, 10);
		System.out.println(news);
		//没有id为10的记录，返回null
	}
	/**
	 * 1、若更新一个持久化对象，不需要显式的调用update方法，因为在调用transaction的commit方法时，
	 * 会先执行session的flush方法
	 * */
	@Test
	public void testUpdate(){
		News news = (News)session.get(News.class, 1);
		news.setTitle("java");
	}
	@Test
	public void testUpdate1(){
		News news = (News)session.get(News.class, 1);
		
		transaction.commit();
		session.close();
		
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		
		news.setTitle("java1");  //不进行更新的操作
		
		//后面会调用destroy方法，执行里面的commit等操作
	}
	/**
	 * 2、更新一个游离对象，需要显式的调用session的update方法，可以把一个游离对象变为持久化对象
	 * */
	@Test
	public void testUpdate2(){
		News news = (News)session.get(News.class, 1);
		
		transaction.commit();
		session.close();
		
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		
		news.setTitle("java1");  
		session.update(news);
	}
	/**
	 * 1、无论要更新的游离对象和数据表的记录是否一致，都会发送update语句
	 * 如何能让update方法不再盲目的发送update语句呢？在.hbm.xml文件的class节点设置
	 * select-before-update=true (默认值为false),但通常不需要设置该属性
	 * */
	@Test
	public void testUpdate3(){
		News news = (News)session.get(News.class, 1);
		
		transaction.commit();
		session.close();
		
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		
		news.setTitle("java2");  
		session.update(news);
	}
	/**
	 * 2、若数据库中没有对应的记录，但是还调用了update方法，则会抛出异常
	 * */
	@Test
	public void testUpdate4(){
		News news = (News)session.get(News.class, 1);
		
		transaction.commit();
		session.close();
		
		news.setId(100);
		
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		
		session.update(news);
	}
	/**
	 * 当update()方法关联一个游离对象时，
	 * 如果在Session的缓存中，已经存在相同OID的持久化对象，会抛出异常。因为在session缓存中，
	 * 不能有两个OID相同的对象
	 * */
	@Test
	public void testUpdate5(){
		News news = (News)session.get(News.class, 1);
		
		transaction.commit();
		session.close();
		
		
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		
		News news2 = (News)session.get(News.class,1);
		
		session.update(news);
	}
	
	/**
	 * 未设置id时，会发出insert语句
	 * */
	@Test
	public void testSaveOrUpdate(){
		News news = new News("F1","f1",new Date());
		session.saveOrUpdate(news);
	}
	/**
	 * 设置了存在的id值时，执行update语句
	 * */
	@Test
	public void testSaveOrUpdate1(){
		News news = new News("F2","f2",new Date());
		news.setId(7);
		session.saveOrUpdate(news);
	}
	
	/**
	 * 若OID不为null，但数据表中还没有和其对应的记录，会抛出一个异常
	 * */
	@Test
	public void testSaveOrUpdate2(){
		News news = new News("F2","f2",new Date());
		news.setId(999);
		session.saveOrUpdate(news);
	}
	/**
	 * 若OID不为null，但数据表中还没有和其对应的记录，会抛出一个异常
	 * 在hbm.xml中为id 配置了unsaved-value后，会执行insert语句
	 * 说明：设置的id 99 并不是数据库库中的id值，两者没有任何关系
	 * */
	@Test
	public void testSaveOrUpdate3(){
		News news = new News("F3","f3",new Date());
		news.setId(99);
		session.saveOrUpdate(news);
		System.out.println(news);
	}
	/**
	 * 临时对象merge，执行insert插入语句
	 * */
	@Test
	public void testMerge(){
		News news = new News("m1","mm1",new Date());
		session.merge(news);
	}
	/**
	 * 游离对象，在session中存在相同oid的持久化对象时，执行update语句
	 * */
	@Test
	public void testMerge1(){
		News news = (News)session.get(News.class, 11);
		session.clear();//变为游离对象
		
		news.setAuthor("merge4"); 
		System.out.println("news:"+news);
		
		News news2 = (News)session.get(News.class, 11);
		System.out.println("news2:"+news2);
		
		session.merge(news);
	}
	/**
	 * 游离对象，在session中不存在相同oid的持久化对象，在数据库中存在id记录，执行update语句
	 * */
	@Test
	public void testMerge2(){
		News news = (News)session.get(News.class, 11);
		session.clear();//变为游离对象
		
		news.setAuthor("merge5"); 
		System.out.println("news:"+news);
		
		session.merge(news);
	}
	/**
	 * 游离对象，在session中不存在相同oid的持久化对象，数据库中不存在相同id的记录，执行insert语句
	 * */
	@Test
	public void testMerge3(){
		News news = (News)session.get(News.class, 11);
		session.clear();//变为游离对象
		news.setId(20);
		news.setAuthor("merge20");
		
		System.out.println("news:"+news);
		
		session.merge(news);
	}
	/**
	 * delete:执行删除操作，只要OID和数据表中一条记录对应，执行delete操作
	 * 若oid在数据表没有对应记录，抛出异常
	 * */
	@Test
	public void testDelete(){
		//游离对象删除
		News news = new News();
		news.setId(10);
		
		session.delete(news);
	}
	@Test
	public void testDelete1(){
		//持久化对象删除
		News news = (News)session.get(News.class, 9);
		
		session.delete(news);
	}
	
	@Test
	public void testDelete2(){
		//持久化对象删除
		News news = (News)session.get(News.class, 99999);
		System.out.println("news:"+news); //news:null
		
		//若oid在数据表中没有对应的记录，则抛出异常
		session.delete(news);
		//java.lang.IllegalArgumentException: 
		//attempt to create delete event with null entity
	}
	
	@Test
	public void testDelete3(){
		//持久化对象删除
		News news = (News)session.get(News.class, 7);
		System.out.println("news:"+news); 
		
		session.delete(news);
		System.out.println("after delete news:"+news);
	}
	/**
	 * evict:从session缓存中把指定的持久化对象移除
	 * */
	@Test
	public void testEvict(){
		News news1 = (News)session.get(News.class, 1);
		News news2 = (News)session.get(News.class, 2);
		
		news1.setTitle("AA");
		news2.setTitle("BB");
		
		session.evict(news1);
	}
	
	@Test
	public void testDoWork(){
		session.doWork(new Work(){

			@Override
			public void execute(Connection connection) throws SQLException {
				// TODO Auto-generated method stub
				System.out.println(connection);
				//调用存储过程或执行jdbc相关的操作方法
			}
			
		});
	}
	@Test
	public void testDynamicUpdate(){
		News news = (News)session.get(News.class, 1);
		news.setAuthor("Oracle123");
	}
	@Test
	public void testIdGenerator() {
		News news = new News("dd","DD",new Date());
		session.save(news);
	}
	@Test
	public void testPropertyUpdate(){
//		News news1 = new News("aa","AA",new Date());
//		session.save(news1);
		
		News news = (News)session.get(News.class, 1);
		news.setTitle("aaa");
		
		System.out.println(news.getDesc());
	}
	@Test
	public void testBlob() throws Exception{
		News news = new News();
		news.setAuthor("cc");
		news.setContent("Content......");
		news.setDate(new Date());
		news.setDesc("desc");
		news.setTitle("CC");
		
		InputStream stream = new FileInputStream("Hydrangeas.jpg");
		Blob image = Hibernate.getLobCreator(session).createBlob(stream, stream.available());
		
		news.setImage(image);
		
		session.save(news);
		
	}
	
	@Test
	public void testBlob1() throws Exception{
		News news = (News)session.get(News.class, 1);
		Blob image = news.getImage();
		
		InputStream in = image.getBinaryStream();
		System.out.println(in.available());
		
	}
	@Test
	public void testComponent(){
		Worker worker = new Worker();
		Pay pay = new Pay();
		
		pay.setMonthlyPay(1000);
		pay.setYearPay(15000);
		pay.setVocationWithPay(500);
		
		worker.setName("zhangsan");
		worker.setPay(pay);
		
		session.save(worker);
	}
}
