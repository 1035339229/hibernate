package com.hibernate.helloworld.n21.both;

public class Zoo {
	
	private Integer zooId;
	private String zooName;

}
