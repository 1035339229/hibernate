package com.hibernate.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.jdbc.Work;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.hibernate.entities.Department;
import com.hibernate.entities.Employee;



public class HibernateTest {

	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	@Before
	public void init(){
		Configuration configuration = new Configuration().configure();
		ServiceRegistry serviceRegistry = 
				new ServiceRegistryBuilder().applySettings(configuration.getProperties())
				                            .buildServiceRegistry();
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
	}
	
	@After
	public void destroy(){
		transaction.commit();
		session.close();
		sessionFactory.close();
	}
	@Test
	public void test(){
		
	}
	@Test
	public void testHQL(){
		//1.创建Query对象
		//基于位置的参数
		String hql = "FROM Employee e WHERE e.salary > ? AND e.email LIKE ? ";
		Query query = session.createQuery(hql);
		
		//2.绑定参数
		//Query对象调用setXxx方法支持方法链的编程风格
		query.setFloat(0, 1000)
			 .setString(1, "%%");
		
		//3.执行查询
		List<Employee> emps = query.list();
		System.out.println(emps.size());
	}
	@Test
	public void testHQLNamedParameter(){
		//基于命名参数
		String hql = "FROM Employee e WHERE e.salary > :sal and e.email LIKE :email";
		Query query = session.createQuery(hql);
		
		query.setFloat("sal", 1000)
			 .setString("email", "%%");
		
		List<Employee> emps = query.list();
		System.out.println(emps.size());
		
	}
	@Test
	public void testHQL2(){
		String hql = "FROM Employee e WHERE e.salary > ? AND e.email LIKE ?  AND e.dept = ? "
				+ " ORDER BY e.salary ";
		Query query = session.createQuery(hql);
		
		Department dept = new Department();
		dept.setId(3);
		
		query.setFloat(0, 1000)
			 .setString(1, "%%")
			 .setEntity(2, dept);
		
		List<Employee> emps = query.list();
		System.out.println(emps.size());
		
	}
	
	@Test
	public void testPageQuery(){
		String hql = "FROM Employee";
		Query query = session.createQuery(hql);
		
		int pageNo = 2;
		int pageSize = 2;
		
		List<Employee> emps = query.setFirstResult((pageNo-1)*pageSize).setMaxResults(pageSize).list();
		
		System.out.println(emps);
	}
	@Test
	public void testNamedQuery(){
		Query query = session.getNamedQuery("salaryEmps");
		List<Employee> emps = query.setFloat("minSal", 1000)
			 .setFloat("maxSal", 5000).list();
		
		System.out.println(emps.size());
	}
	@Test
	public void testFieldQuery(){
		String hql = "SELECT e.email,e.salary,e.dept FROM Employee e WHERE e.dept = :dept";
		Query query = session.createQuery(hql);
		
		Department dept = new Department();
		dept.setId(1);
		
		List<Object[]> result = query.setEntity("dept", dept).list();
		
		for(Object[] objs:result){
			System.out.println(Arrays.asList(objs));
		}
	}
	
	@Test
	public void testFieldQuery2(){
		String hql = "SELECT new Employee(e.salary,e.email,e.dept) FROM Employee e WHERE e.dept = :dept";
		Query query = session.createQuery(hql);
		
		Department dept = new Department();
		dept.setId(1);
		
		List<Employee> result = query.setEntity("dept", dept).list();
		
		for(Employee emp:result){
			System.out.println(emp.getId()+","+emp.getEmail()+","+emp.getSalary()+","+emp.getDept());
		}
	}
	@Test
	public void testGroupBy(){
		String hql = "SELECT min(e.salary),max(e.salary) FROM Employee e "
				+ "GROUP BY e.dept HAVING min(salary) > :minSal";
		
		Query query = session.createQuery(hql);
		List<Object[]> result = query.setFloat("minSal", 1000).list();
		for(Object[] objs:result){
			System.out.println(Arrays.asList(objs));
		}
	}
	@Test
	public void testleftjoinFetch(){
		String hql = "FROM Department d LEFT JOIN	d.emps";
//		String hql = "Select Distinct d FROM Department d LEFT JOIN FETCH	d.emps";
		Query query = session.createQuery(hql);
		
//		List<Department> depts = query.list();
//		System.out.println(depts.size());
//		for(Department dept:depts){
//			System.out.println(dept);
//		}
		
		List<Object[]> result = query.list();
		System.out.println(result);
		
		for(Object[] obj:result){
			System.out.println(Arrays.asList(obj));
			
		}
	}
	
	@Test
	public void testleftjoin(){
		String hql = "Select Distinct d FROM Department d LEFT JOIN d.emps";
		Query query = session.createQuery(hql);
		
		List<Department> depts = query.list();
		System.out.println(depts.size());
		
		for(Department dept : depts){
//			System.out.println(dept);
			System.out.println(dept.getName()+","+dept.getEmps().size());
		}
	}
	@Test
	public void testInnerJoinFetch(){
		String hql = "SELECT DISTINCT d FROM Department d INNER JOIN FETCH d.emps";
		Query query = session.createQuery(hql);
		
		List<Department> depts = query.list();
		System.out.println(depts.size());
		
		for(Department dept : depts){
//			System.out.println(dept);
			System.out.println(dept.getName()+","+dept.getEmps().size());
		}
	}
	@Test
	public void testInnerJoin(){
		String hql = "SELECT DISTINCT d FROM Department d INNER JOIN d.emps";
		Query query = session.createQuery(hql);
		
		List<Department> depts = query.list();
		System.out.println(depts.size());
		
		for(Department dept : depts){
//			System.out.println(dept);
			System.out.println(dept.getName()+","+dept.getEmps().size());
		}
	}
	@Test
	public void testInnerJoinFetch1(){
		String hql = "SELECT e FROM Employee e INNER JOIN FETCH e.dept";
		Query query = session.createQuery(hql);
		
		List<Employee> emps = query.list();
		System.out.println(emps.size());
		
		for(Employee emp : emps){
			System.out.println(emp.getName()+","+emp.getDept().getName());
		}
	}
	
	@Test
	public void testInnerJoin1(){
		String hql = "SELECT e FROM Employee e INNER JOIN e.dept";
		Query query = session.createQuery(hql);
		
		List<Employee> emps = query.list();
		System.out.println(emps.size());
		
		for(Employee emp : emps){
			System.out.println(emp.getName()+","+emp.getDept().getName());
		}
	}
	@Test
	public void testQBC(){
		//1.创建一个Criteria对象
		Criteria criteria = session.createCriteria(Employee.class);
		//2.添加查询条件：在QBC中查询条件使用Criterion来表示
		criteria.add(Restrictions.eq("email", "emp2@a.com"));
		criteria.add(Restrictions.gt("salary", 1000F));
		//3.执行查询
		Employee emp = (Employee)criteria.uniqueResult();
		System.out.println(emp);
	}
	
	@Test
	public void testQBC2(){
		Criteria criteria = session.createCriteria(Employee.class);
		
		//AND:
		Conjunction conjunction = Restrictions.conjunction();
		conjunction.add(Restrictions.like("name", "1",MatchMode.ANYWHERE));
		
		Department dept = new Department();
		dept.setId(1);
		
		conjunction.add(Restrictions.eq("dept", dept));
		
		System.out.println(conjunction);
		
		//OR:
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(Restrictions.ge("salary", 2000F));
		disjunction.add(Restrictions.isNotNull("email"));
		
		criteria.add(conjunction);
		criteria.add(disjunction);
		
		criteria.list();
		
	}
	
	@Test
	public void testQBC3(){
		Criteria criteria = session.createCriteria(Employee.class);
		
		//统计查询：
		criteria.setProjection(Projections.max("salary"));
		
		System.out.println(criteria.uniqueResult());

		
	}
	@Test
	public void testQBC4(){
		Criteria criteria = session.createCriteria(Employee.class);
		//1.添加排序
		criteria.addOrder(Order.asc("salary"));
		criteria.addOrder(Order.desc("email"));
		//2.添加翻页方法
		int pageSize=2;
		int pageNo=2;
		
		criteria.setFirstResult((pageNo-1)*pageSize).setMaxResults(pageSize).list();
	}
	@Test
	public void testNativeSQL(){
		String sql = "insert into HP_DEPARTMENT values(?,?)";
		Query query = session.createSQLQuery(sql);
		
		query.setInteger(0, 28);
		query.setString(1, "deptXX");
		query.executeUpdate();
	}
	@Test
	public void testHQLUpdate(){
//		String hql = "DELETE FROM Department d WHERE d.id = :id";
//		
//		session.createQuery(hql).setInteger("id", 28).executeUpdate();
		
		String hql1 = "insert into Department(id,name) select u.id+1,u.name from Department u where u.id=3";
		
		session.createQuery(hql1).executeUpdate();
		
		//不支持下面的写法
//		String hql1 = "insert into Department(id,name) values(?,?)";
//		
//		session.createQuery(hql1).setInteger(0, 4).setString(1, "vv").executeUpdate();

		
	}
}
